# Error handling ensures that our program does not crash when it 
# encounters unexpected inputs or issues. 
# Instead, it gracefully handles errors, logs them, and allows execution 
# to continue.

import logging

logging.basicConfig(level=logging.DEBUG)  # Set logging level

def is_palindrome(word):
    """ Check if a word or phrase is a palindrome using error handling. """
    
    try:
        if not isinstance(word, str):
            raise TypeError("Input must be a string")
        
        logging.debug(f"Original: {word}")
        word = word.lower().replace(" ", "")
        logging.debug(f"Processed: {word}")

        result = word == word[::-1]
        logging.debug(f"Result: {result}")
        return result
    
    except TypeError as e:
        logging.error(f"TypeError: {e}")
        return None
    except Exception as e:
        logging.error(f"Unexpected Error: {e}")
        return None

# Test Cases
print(is_palindrome("No lemon no melon"))  # Debugging output + Expected: True
print(is_palindrome("Hello"))              # Debugging output + Expected: False
print(is_palindrome(12345))                # Logging error + Expected: None
print(is_palindrome(None))                 # Logging error + Expected: None
