#Handling Spaces


def is_palindrome(word):
    """ Check if a word or phrase is a palindrome (ignores case and spaces). """
    word = word.lower().replace(" ", "")  # Convert to lowercase and remove spaces
    return word == word[::-1]

# Test Cases
print(is_palindrome("No lemon no melon"))  # Expected: True
# print(is_palindrome("madam"))              # Expected: True
# print(is_palindrome("hello"))              # Expected: False



#If a number is passed, our function will break (AttributeError). Let's add error handling.
print(is_palindrome(12321))  
