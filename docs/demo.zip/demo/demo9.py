import logging

# Configure logging to write to a file
logging.basicConfig(
    filename='palindrome_debug.log',  # Name of log file
    level=logging.DEBUG,  # Set the logging level
    format='%(asctime)s - %(levelname)s - %(message)s',  # Formatting logs
    filemode='w'  # Overwrite the file each time ('a' to append)
)

def is_palindrome(word):
    """Check if a word is a palindrome with logging."""
    try:
        assert isinstance(word, str), "Input must be a string"
        
        logging.debug(f"Original: {word}")
        word = word.lower().replace(" ", "")
        logging.debug(f"Processed: {word}")

        result = word == word[::-1]
        logging.debug(f"Palindrome result: {result}")
        return result
    
    except AssertionError as e:
        logging.error(f"AssertionError: {e}")
        return None
    except Exception as e:
        logging.error(f"Unexpected Error: {e}")
        return None

# Test Cases
print(is_palindrome("No lemon no melon"))  # Logs stored in file
print(is_palindrome(12321))  # Logs assertion error
