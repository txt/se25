#Handling Case Sensitivity


def is_palindrome(word):
    """ Check if a word is a palindrome (case insensitive). """
    word = word.lower()  # Convert to lowercase
    return word == word[::-1]

# Test Cases
# print(is_palindrome("madam"))   # Expected: True
# print(is_palindrome("Madam"))   # Expected: True
# print(is_palindrome("hello"))   # Expected: False


#If a phrase like "No lemon no melon" is entered, our function will fail. Let's strip spaces.

print(is_palindrome("No lemon no melon"))  # Expected: True but got False
