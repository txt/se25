# Using Assertions for Debugging
# Assertions help catch unexpected behavior early.

import logging

logging.basicConfig(level=logging.DEBUG)  # Set logging level

def is_palindrome(word):
    """ Check if a word or phrase is a palindrome using assertions. """
    try:
        #Assertions (assert) are checks that help find errors early.
        #They stop the program if a condition is false.
        assert isinstance(word, str), "Input must be a string"  # Assert input is string
        
        logging.debug(f"Original: {word}")
        word = word.lower().replace(" ", "")
        logging.debug(f"Processed: {word}")

        result = word == word[::-1]
        logging.debug(f"Result: {result}")
        return result
    
    #Assertions help catch unexpected inputs early.
    except AssertionError as e:
        logging.error(f"AssertionError: {e}")
        return None
    #Exception handling prevents program crashes.
    except Exception as e:
        logging.error(f"Unexpected Error: {e}")
        return None

# Test Cases
print(is_palindrome("No lemon no melon"))  # Debugging output + Expected: True
print(is_palindrome("Hello"))              # Debugging output + Expected: False
print(is_palindrome(12345))                # AssertionError + Expected: None
print(is_palindrome(None))                 # AssertionError + Expected: None

#Systematic debugging (instead of random guessing) makes finding and fixing errors easier.
