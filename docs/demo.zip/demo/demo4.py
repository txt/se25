#Handling Non-String Input (Runtime Errors)


def is_palindrome(word):
    """ Check if a word or phrase is a palindrome (handles non-string input). """
    if not isinstance(word, str):
        print("Non-strings value")
        return None
    word = word.lower().replace(" ", "")
    return word == word[::-1]

# Test Cases
# print(is_palindrome("No lemon no melon"))  # Expected: True
print(is_palindrome(12321))                # Expected: False (not a string)
