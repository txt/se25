def is_palindrome(word):
    """ Check if a word or phrase is a palindrome with print debugging. """
    if not isinstance(word, str):
        print("Error: Input is not a string")
            
    print(f"Original: {word}")
    word = word.lower().replace(" ", "")
    print(f"Processed: {word}")

    result = word == word[::-1]
    print(f"Result: {result}")
    return result

# Test Cases
print(is_palindrome("No lemon no melon"))  # Debugging output + Expected: True
print(is_palindrome("Hello"))              # Debugging output + Expected: False
