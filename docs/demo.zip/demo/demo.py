# A palindrome is a word, phrase, number, or sequence that reads the same forward and 
# backward (ignoring spaces, punctuation, and capitalization).


# Basic Palindrome Checker

def is_palindrome(word):
    """ Check if a word is a palindrome. """
    return word == word[::-1]  # Reverse the word and compare

# Test Cases
# print(is_palindrome("madam"))   # Expected: True
# print(is_palindrome("hello"))   # Expected: False
# print(is_palindrome("racecar")) # Expected: True


#Right now, "Madam" would return False because Python is case-sensitive. Let's fix that.

print(is_palindrome("Madam"))   # Expected: True but got False
