import logging

logging.basicConfig(level=logging.DEBUG)  # Set logging level
#Supports DEBUG, INFO, WARNING, ERROR, CRITICAL


def is_palindrome(word):
    """ Check if a word or phrase is a palindrome using logging. """
    if not isinstance(word, str):
        logging.error("Error: Input is not a string")
        print("Error: Input is not a string")
        return None
    
    logging.debug(f"Original: {word}")
    word = word.lower().replace(" ", "")
    logging.debug(f"Processed: {word}")

    result = word == word[::-1]
    logging.debug(f"Result: {result}")
    return result

# Test Cases
print(is_palindrome("No lemon no melon"))  # Debugging output + Expected: True
print(is_palindrome("Hello"))              # Debugging output + Expected: False
print(is_palindrome(12345))                # Logging error + Expected: False



#Print debugging is useful but logging is better for structured debugging.

